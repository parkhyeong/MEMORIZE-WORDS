package com.example.admin_voca;

import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class voca_add_c {
private String word;
private  String meaning;

public void setWord(String word){this.word=word;}
public void setMeaning(String meaning){this.meaning=meaning;}
    public void Add_Voca(String Sword){
        try {
            FileWriter fw = new FileWriter("/data/data/com.example.admin_voca/words.txt",false);
            BufferedWriter bufwr = new BufferedWriter(fw) ;
            bufwr.write(Sword + System.lineSeparator());

            bufwr.close();
            fw.close();
        }catch(Exception e){
            File file = new File("/data/data/com.example.admin_voca/words.txt");
            e.printStackTrace();
        }
    }
}
